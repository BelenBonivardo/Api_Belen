package com.example.apibonivardo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApiBonivardoApplicationTests {

    public static void main(String[] args) {
        SpringApplication.run(ApiBonivardoApplicationTests.class, args);
    }

}
