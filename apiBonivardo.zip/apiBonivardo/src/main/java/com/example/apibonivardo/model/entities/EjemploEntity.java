package com.example.apibonivardo.model.entities;

import lombok.Data;

import javax.persistence.*;

@Table(name="ejemplos")
@Entity
@Data
public class EjemploEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idEjemplos;
    private String contenidoEjemplo;
    private String descripcionEjemplo;
}

