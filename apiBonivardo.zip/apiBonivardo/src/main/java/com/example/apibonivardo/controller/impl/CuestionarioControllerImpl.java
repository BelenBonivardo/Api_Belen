package com.example.apibonivardo.controller.impl;
import com.example.apibonivardo.model.dto.PreguntaDTO;

import java.util.List;

public class CuestionarioControllerImpl implements CuestionarioController {

    @Override
    public List<PreguntaDTO> traerCuestionarioConcepto(Long id) {
        return null;
    }

    @Override
    public Boolean validarRespuesta(Long idRespuesta, Long idPregunta){
        return null;
    }
}



