package com.example.apibonivardo.controller.impl;
import com.example.apibonivardo.model.dto.ConceptoDTO;
import com.example.apibonivardo.service.ConceptoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("concepto")
@RestController
public class ConceptoControllerImpl implements ConceptoController{
    private static final Logger loggerController =
            LoggerFactory.getLogger(ConceptoController.class);

    @Autowired
    ConceptoService conceptoService;


    @Override
    @RequestMapping(value = "/conceptos", method = RequestMethod.GET, produces = "application/json")
    public List<ConceptoDTO> obtenerConceptos() {
        return conceptoService.obtenerConceptos();
    }

    @Override
    @PostMapping("/crear")
    public String crearConcepto(@RequestBody ConceptoDTO concepto) {
        loggerController.info("Crear concepto");
        return conceptoService.crearConcepto(concepto);

    }

    @Override
    @PutMapping("/actualizar")
    public String actualizarConcepto(ConceptoDTO conceptoActual) {
        loggerController.info("Actualizar concepto");
        return conceptoService.crearConcepto(conceptoActual);
    }

    @Override
    @DeleteMapping("/eliminar")
    public String eliminarConcepto(ConceptoDTO eliminarConceptos) {
        loggerController.info("Eliminar concepto");
        return conceptoService.eliminarConcepto(eliminarConceptos);
    }

}



