package com.example.apibonivardo.controller.impl;

import com.example.apibonivardo.model.dto.ConceptoDTO;

public interface ConceptoController {
    String crearConcepto(ConceptoDTO concepto);

   /* String actualizarConcepto(ConceptoDTO conceptoActual);

    String eliminarConcepto(ConceptoDTO eliminarConcepto);

    String mostrarConcepto();

    String enviarConsejo();

    String generarReporte(String mail);*/

}
