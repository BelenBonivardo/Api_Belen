package com.example.apibonivardo.controller.impl;

import com.example.apibonivardo.model.dto.ConceptoDTO;
import com.example.apibonivardo.model.entities.ConceptoEntity;

import java.util.List;

public interface ConceptoController {

    List<ConceptoDTO> obtenerConceptos();

    String crearConcepto(ConceptoDTO concepto);

    String actualizarConcepto(ConceptoDTO conceptoActual);

    String eliminarConcepto(ConceptoDTO eliminarConcepto);


}
