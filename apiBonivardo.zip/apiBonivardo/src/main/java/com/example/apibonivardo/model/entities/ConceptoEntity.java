package com.example.apibonivardo.model.entities;

import lombok.Data;

import javax.persistence.*;

@Table(name="conceptos")
@Entity
@Data
public class ConceptoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_concepto;
    private String nombre_concepto;
    private int numero_concepto;
    private String contenido_concepto;

}
