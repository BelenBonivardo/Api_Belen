package com.example.apibonivardo.model.dto;

import lombok.Data;

import java.io.Serializable;
@Data
public class EjemploDTO implements Serializable {

    private int idEjemplos;
    private String contenidoEjemplo;
    private String descripcionEjemplo;
}

