package com.example.apibonivardo.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
@Getter
@Setter
public class EjemploDTO implements Serializable {
    private int id_ejemplos;
    private String contenido_ejemplo;
    private String descripcion_ejemplo;



}