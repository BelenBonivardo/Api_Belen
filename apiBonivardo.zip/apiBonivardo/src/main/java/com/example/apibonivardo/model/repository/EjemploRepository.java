package com.example.apibonivardo.model.repository;

import com.example.apibonivardo.model.entities.EjemploEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EjemploRepository extends JpaRepository<EjemploEntity, Long> {
}
