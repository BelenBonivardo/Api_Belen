package com.example.apibonivardo.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PreguntaDTO {
    private Long id_pregunta;
    private String contenido_pregunta;
    private List<RespuestaDTO> listaRespuestas;
}
