package com.example.apibonivardo.model.dto;

import lombok.Data;

import java.io.Serializable;
@Data
public class PreguntaDTO implements Serializable {
    private Long idPregunta;
    private String contenidoPregunta;
    private int idRespuesta;
}
