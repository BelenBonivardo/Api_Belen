package com.example.apibonivardo.service.impl;

import com.example.apibonivardo.model.dto.ConceptoDTO;
import com.example.apibonivardo.model.entities.ConceptoEntity;
import com.example.apibonivardo.model.repository.ConceptoRepository;
import com.example.apibonivardo.service.ConceptoService;
import net.bytebuddy.asm.Advice;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ConceptoServiceImpl implements ConceptoService {
    @Autowired
    ConceptoRepository conceptoRepository;
    ModelMapper modelMapper = new ModelMapper();

    @Override

    public String crearConcepto(ConceptoDTO crear) {
        ConceptoEntity concepto = new ConceptoEntity();
        concepto = modelMapper.map(crear, ConceptoEntity.class);
        conceptoRepository.save(concepto);
        return "Creaste un concepto nuevo";
    }


    @Override
    public String actualizarConcepto(ConceptoDTO actualizarConcepto) {
        ConceptoEntity actconcepto = new ConceptoEntity();
        actconcepto = modelMapper.map(actualizarConcepto, ConceptoEntity.class);
        conceptoRepository.save(actconcepto);
        return "Estas actualizando un concepto";
    }


    @Override
    public String eliminarConcepto(ConceptoDTO eliminar) {
        ConceptoEntity eliminarconcepto = new ConceptoEntity();
        eliminarconcepto = modelMapper.map(eliminar, ConceptoEntity.class);
        System.out.println("Eliminar concepto" + eliminar.toString());
        conceptoRepository.delete(eliminarconcepto);
        return "Ha eliminado un concepto";
    }

    @Override
    public List<ConceptoDTO> obtenerConceptos(){
        List<ConceptoEntity>  concepto = conceptoRepository.findAll();
        List<ConceptoDTO> conceptoDTO = new ArrayList<>();
        for (ConceptoEntity conceptoEntity:concepto) {
            ConceptoDTO conceptosDTO = modelMapper.map(conceptoEntity, ConceptoDTO.class);
            conceptoDTO.add(conceptosDTO);


        }
        return conceptoDTO;
    }

}
