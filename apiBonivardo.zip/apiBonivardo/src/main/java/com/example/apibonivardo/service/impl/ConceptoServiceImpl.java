package com.example.apibonivardo.service.impl;

import com.example.apibonivardo.model.dto.ConceptoDTO;
import com.example.apibonivardo.model.repository.ConceptoRepository;
import com.example.apibonivardo.service.ConceptoService;
import net.bytebuddy.asm.Advice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConceptoServiceImpl implements ConceptoService {
    @Autowired
    ConceptoRepository conceptoRepository;


    @Override
    public String crearConcepto(ConceptoDTO concepto) {
        System.out.println("Crear Concepto" + concepto.toString());
        ;
        conceptoRepository.save(concepto);
        return "Usted ha creado un concepto nuevo";
    }
}

   /* @Override
    public String ActualizarConcepto(ConceptoDTO conceptoActual) {
        System.out.println("Actualizar concepto"+ conceptoActual.toString());
        conceptoRepository.save(conceptoActual);
        return "Usted ha actualizado un concepto";
    }
    @Override
    public String eliminarConcepto(ConceptoDTO eliminarConcepto) {
        System.out.println("Eliminar concepto"+ eliminarConcepto.toString());
        conceptoRepository.delete(eliminarConcepto);
        return"Ha eliminado un concepto";
    }
}
*/