package com.example.apibonivardo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBonivardoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiBonivardoApplication.class, args);
    }

}
