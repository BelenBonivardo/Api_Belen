package com.example.apibonivardo.model.dto;

import com.example.apibonivardo.model.entities.ConceptoEntity;
import lombok.*;

import java.io.Serializable;


@Data

public class ConceptoDTO  implements Serializable {
    private int idConcepto;
    private String nombreConcepto;
    private int numeroConcepto;
    private String contenidoConcepto;

}



