package com.example.apibonivardo.service;

public interface PreguntaService {
}
