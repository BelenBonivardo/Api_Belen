package com.example.apibonivardo.model.repository;

import com.example.apibonivardo.model.entities.RespuestaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RespuestaRepository extends JpaRepository<RespuestaEntity, Long> {
}
