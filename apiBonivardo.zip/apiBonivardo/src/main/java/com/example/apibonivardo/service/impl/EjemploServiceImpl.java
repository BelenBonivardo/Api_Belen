package com.example.apibonivardo.service.impl;

public class EjemploServiceImpl {
}
