package com.example.apibonivardo.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.sql.Timestamp;
@Data
@AllArgsConstructor
public class ExcepcionesDTO {
    private Timestamp timestamp;
    private String data;
    private int respondeCode;
    private String status;

}
