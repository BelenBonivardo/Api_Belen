package com.example.apibonivardo.model.dto;

import lombok.Data;

import java.io.Serializable;
@Data
public class RespuestaDTO implements Serializable {
    private int idRespuesta;
    private String contenidoRespuestas;
    private int idPregunta;
}
