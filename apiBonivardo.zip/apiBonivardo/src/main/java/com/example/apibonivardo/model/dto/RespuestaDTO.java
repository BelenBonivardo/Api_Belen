package com.example.apibonivardo.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RespuestaDTO {
    private int id_respuesta;
    private String contenido_respuestas;
    private boolean es_correcta;
    private int id_pregunta;

}
