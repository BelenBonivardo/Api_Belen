package com.example.apibonivardo.service;

public interface EjemploService {
    interface RespuestaService {
    }
}
