package com.example.apibonivardo.excepciones;

import com.example.apibonivardo.model.dto.ExcepcionesDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class ErroresGlobales {
    @ControllerAdvice
    public class ExceptionGlobalResponse {
        private ExcepcionesDTO result;

        @ExceptionHandler(RuntimeException.class)
        public ResponseEntity<ExcepcionesDTO> runtimeException(RuntimeException e) {
            result = new ExcepcionesDTO(Time.getTime(), "[Exception Response] - Exception: "
                    + e.getMessage(), 500, "Error");
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        @ExceptionHandler(Exception.class)
        public ResponseEntity<ExcepcionesDTO> exception(Exception e) {
            result = new ExcepcionesDTO(Time.getTime(), "[Exception Response] - Exception: "
                    + e.getMessage(), 500, "Error");
            return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
