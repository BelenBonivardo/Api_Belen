package com.example.apibonivardo.controller.impl;

import com.example.apibonivardo.model.dto.ConceptoDTO;
import com.example.apibonivardo.service.ConceptoService;
import com.example.apibonivardo.service.impl.ConceptoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("Concepto")
@RestController
public class ConceptoControlerImpl implements ConceptoController{

    @Autowired
    ConceptoService conceptoService;
    @Override
    @PostMapping("/crear")
    public String crearConcepto(@RequestBody ConceptoDTO concepto) {
        System.out.println("Crear:"+ concepto.toString());
        return conceptoService.crearConcepto(concepto);

    }

   /* @Override
    @PutMapping("/actualizar")
    public String actualizarConcepto(ConceptoDTO conceptoActual) {
        return null;
    }

    @Override
    @DeleteMapping("/eliminar")
    public String eliminarConcepto(ConceptoDTO eliminarConcepto) {
        return null;
    }
    @GetMapping("/conceptos")
    @Override
    public String mostrarConcepto() {
        return "Lista de conceptos";
    }

    @Override
    @GetMapping("/enviar consejo{mail}")
    public java.lang.String enviarConsejo() {
        return null;
    }

    @Override
    public String generarReporte(String mail) {
        return null;
    }*/




}
