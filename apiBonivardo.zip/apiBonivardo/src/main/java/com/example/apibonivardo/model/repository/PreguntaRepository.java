package com.example.apibonivardo.model.repository;

import com.example.apibonivardo.model.entities.PreguntaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PreguntaRepository extends JpaRepository<PreguntaEntity, Long> {
}
