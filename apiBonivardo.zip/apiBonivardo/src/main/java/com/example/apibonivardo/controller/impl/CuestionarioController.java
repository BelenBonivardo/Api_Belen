package com.example.apibonivardo.controller.impl;

import com.example.apibonivardo.model.dto.PreguntaDTO;

import java.util.List;

public interface CuestionarioController {

  List<PreguntaDTO> traerCuestionarioConcepto(Long id);


  Boolean validarRespuesta(Long idRespuesta, Long idPregunta);

}



