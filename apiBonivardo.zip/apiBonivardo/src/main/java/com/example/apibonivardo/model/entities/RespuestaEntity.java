package com.example.apibonivardo.model.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="respuestas")
@Getter
@Setter
public class RespuestaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_respuesta;
    private String contenido_respuestas;
    private boolean es_correcta;
    private int id_pregunta;

}
