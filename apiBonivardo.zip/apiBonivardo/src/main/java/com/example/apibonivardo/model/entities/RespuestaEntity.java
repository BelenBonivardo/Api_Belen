package com.example.apibonivardo.model.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name="respuestas")
@Getter
@Setter
public class RespuestaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idRespuesta;
    private String contenidoRespuestas;
    private boolean esCorrecta;
    private int idPregunta;

}
