package com.example.apibonivardo.model.repository;

import com.example.apibonivardo.model.dto.ConceptoDTO;
import com.example.apibonivardo.model.entities.ConceptoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConceptoRepository extends JpaRepository<ConceptoDTO, Long> {
}
