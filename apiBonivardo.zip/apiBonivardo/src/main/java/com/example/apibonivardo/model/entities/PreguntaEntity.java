package com.example.apibonivardo.model.entities;


import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Table(name="preguntas")
@Entity
@Data
public class PreguntaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPregunta;
    private String contenidoPregunta;
    private Long idConcepto;

}