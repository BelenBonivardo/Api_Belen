package com.example.apibonivardo.model.entities;

import com.example.apibonivardo.model.dto.RespuestaDTO;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Table(name="preguntas")
@Entity
@Data
public class PreguntaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_pregunta;
    private String contenido_pregunta;

}