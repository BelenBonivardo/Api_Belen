package com.example.apibonivardo.service;

import com.example.apibonivardo.model.dto.ConceptoDTO;

public interface ConceptoService {
    String crearConcepto(ConceptoDTO concepto);}

/*    String actualizarConcepto(ConceptoDTO conceptoActual);

    String eliminarConcepto(ConceptoDTO eliminarConcepto);
}*/
